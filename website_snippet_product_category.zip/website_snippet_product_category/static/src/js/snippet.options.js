/** @odoo-module */

import options from 'web_editor.snippets.options';

odoo.define("website_snippet_product_category.snippet_options", function (require) {
    "use strict";

    console.log("import options from web_editor.snippets.options")

    options.registry.js_product_category = options.Class.extend({
        /**
         * @override
         */
        cleanForSave: function () {
            this._super.apply(this, arguments);
            this.$target.empty();
        },
    });
});
