* The snippet shows a maximum of 4 levels by design.
* Add a option to configure the initial level
* Add a option to select how many levels can be represented
* Handle large amounts of categories
