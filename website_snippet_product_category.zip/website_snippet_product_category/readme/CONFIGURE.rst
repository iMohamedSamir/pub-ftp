You can select what categories can be shown by the snippet and an image for the category:

#. Go to website (backend) > eCommerce > eCommerce Categories
#. Create or Edit one
#. You can see two new options "Published in product category snippet" and "Category Image"
