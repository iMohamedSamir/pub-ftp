Adds a new snippet to show e-commerce categories
