# Copyright 2024 WizMoe - Mohamed Samir
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
{
    "name": "Website Snippet For Product Category",
    "category": "Website",
    "summary": "Adds a new snippet to show e-commerce categories",
    "version": "16.0",
    "license": "LGPL-3",
    "website": "https://wizmoe.com",
    "author": "Mohamed Samir",
    "depends": ["website_sale"],
    "data": [
        "templates/snippets.xml",
        "views/product_public_category.xml",
    ],
    "assets": {
        "web.assets_frontend": [
            "/website_snippet_product_category/static/src/scss/snippet.scss",
            "/website_snippet_product_category/static/src/js/frontend.js",
        ],
        "website.assets_editor": [
            "/website_snippet_product_category/static/src/js/snippet.options.js",
        ],
    },
    "demo": ["demo/demo.xml", "demo/pages.xml"],
    "maintainers": ["Tardo"],
    "installable": True,
}
