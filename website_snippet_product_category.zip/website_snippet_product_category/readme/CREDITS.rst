static/img/boxes_32.png - https://www.iconninja.com/box-mario-icon-30561
